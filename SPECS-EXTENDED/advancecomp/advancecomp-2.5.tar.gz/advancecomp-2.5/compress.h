/*
 * This file is part of the Advance project.
 *
 * Copyright (C) 2002 Andrea Mazzoleni
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details. 
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#ifndef __COMPRESS_H
#define __COMPRESS_H

#include "7z/7z.h"

extern "C" {
#include "libdeflate/libdeflate.h"
}

extern "C" {
#include "zopfli/zopfli.h"
}

#if USE_BZIP2
#include <bzlib.h>
#endif

#include <zlib.h>

#define RETRY_FOR_SMALL_FILES 65536 /**< Size for which we try multiple algorithms */

unsigned oversize_deflate(unsigned size);
unsigned oversize_zlib(unsigned size);

bool decompress_deflate_zlib(const unsigned char* in_data, unsigned in_size, unsigned char* out_data, unsigned out_size);
bool compress_deflate_zlib(const unsigned char* in_data, unsigned in_size, unsigned char* out_data, unsigned& out_size, int compression_level, int strategy, int mem_level);

bool decompress_bzip2(const unsigned char* in_data, unsigned in_size, unsigned char* out_data, unsigned out_size);
bool compress_bzip2(const unsigned char* in_data, unsigned in_size, unsigned char* out_data, unsigned& out_size, int blocksize, int workfactor);

bool decompress_rfc1950_zlib(const unsigned char* in_data, unsigned in_size, unsigned char* out_data, unsigned out_size);
bool compress_rfc1950_zlib(const unsigned char* in_data, unsigned in_size, unsigned char* out_data, unsigned& out_size, int compression_level, int strategy, int mem_level);

bool compress_deflate_libdeflate(const unsigned char* in_data, unsigned in_size, unsigned char* out_data, unsigned& out_size, int compression_level);
bool compress_rfc1950_libdeflate(const unsigned char* in_data, unsigned in_size, unsigned char* out_data, unsigned& out_size, int compression_level);

enum shrink_level_t {
	shrink_none,
	shrink_fast,
	shrink_normal,
	shrink_extra,
	shrink_insane
};

struct shrink_t {
	enum shrink_level_t level;
	unsigned iter;
};

bool compress_zlib(shrink_t level, unsigned char* out_data, unsigned& out_size, const unsigned char* in_data, unsigned in_size);
bool compress_deflate(shrink_t level, unsigned char* out_data, unsigned& out_size, const unsigned char* in_data, unsigned in_size);

#endif
