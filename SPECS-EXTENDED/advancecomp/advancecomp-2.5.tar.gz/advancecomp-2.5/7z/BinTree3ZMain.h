#ifndef __BINTREE3ZMAIN__H
#define __BINTREE3ZMAIN__H

#undef BT_NAMESPACE
#define BT_NAMESPACE NBT3Z

#define HASH_ZIP

#include "BinTreeMain.h"

#undef HASH_ZIP

#endif

