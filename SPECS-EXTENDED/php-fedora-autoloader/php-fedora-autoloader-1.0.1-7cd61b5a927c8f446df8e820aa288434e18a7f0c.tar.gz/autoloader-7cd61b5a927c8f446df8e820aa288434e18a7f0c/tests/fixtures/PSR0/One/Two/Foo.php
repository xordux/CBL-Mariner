<?php

namespace One\Two;

class Foo
{
}
