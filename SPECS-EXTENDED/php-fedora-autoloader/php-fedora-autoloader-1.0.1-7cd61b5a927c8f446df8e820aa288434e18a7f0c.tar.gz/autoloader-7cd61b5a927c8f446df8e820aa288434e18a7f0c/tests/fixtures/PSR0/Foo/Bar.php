<?php

class Foo_Bar
{
}
