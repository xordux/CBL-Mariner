<?php

namespace One_Two;

class Foo
{
}
