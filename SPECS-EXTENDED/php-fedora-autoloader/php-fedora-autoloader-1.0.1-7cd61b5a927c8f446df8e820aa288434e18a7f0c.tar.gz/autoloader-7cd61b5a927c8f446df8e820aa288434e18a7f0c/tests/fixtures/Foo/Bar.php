<?php

namespace Foo;

class Bar
{
    const order = 'one';
}
