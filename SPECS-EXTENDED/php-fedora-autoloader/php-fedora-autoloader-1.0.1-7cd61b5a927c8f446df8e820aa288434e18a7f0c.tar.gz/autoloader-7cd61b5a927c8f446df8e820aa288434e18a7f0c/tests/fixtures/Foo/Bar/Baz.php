<?php

namespace Foo\Bar;

class Baz
{
}
