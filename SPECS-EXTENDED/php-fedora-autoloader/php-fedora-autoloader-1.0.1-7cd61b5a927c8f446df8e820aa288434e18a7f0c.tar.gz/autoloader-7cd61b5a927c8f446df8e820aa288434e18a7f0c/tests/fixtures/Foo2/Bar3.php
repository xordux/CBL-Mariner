<?php

namespace Foo;

class Bar
{
    const order = 'three';
}
