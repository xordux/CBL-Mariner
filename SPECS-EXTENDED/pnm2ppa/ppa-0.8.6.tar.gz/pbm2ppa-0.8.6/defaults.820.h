/* defaults.h
 * Default printer values.  Edit these and recompile if so desired.
 * [Note: a /etc/pbm2ppa.conf file will override these]
 */
#ifndef _DEFAULTS_H
#define _DEFAULTS_H

#define DEFAULT_PRINTER        ( HP820 )

/* Refer to CALIBRATION file about these settings */
#define DEFAULT_X_OFFSET       (    75 )
#define DEFAULT_Y_OFFSET       (  -500 )

#define DEFAULT_TOP_MARGIN     (    80 )
#define DEFAULT_LEFT_MARGIN    (    80 )
#define DEFAULT_RIGHT_MARGIN   (    80 )
#define DEFAULT_BOTTOM_MARGIN  (   150 )

#endif
