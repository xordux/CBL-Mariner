// SPDX-License-Identifier: Apache-2.0

use super::super::{NmSettingVlan, ToKeyfile};

impl ToKeyfile for NmSettingVlan {}
