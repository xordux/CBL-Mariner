// SPDX-License-Identifier: Apache-2.0

use super::super::{NmSettingVxlan, ToKeyfile};

impl ToKeyfile for NmSettingVxlan {}
