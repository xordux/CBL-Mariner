function [P, stats] = csymamdtestmex (A, knobs)				    %#ok
% CSYMAMDTESTMEX test function for csymamd
% Example:
%   [ P, stats ] = csymamdtest (A, knobs) ;
% See also csymamd

% Copyright 1998-2007, Timothy A. Davis, Stefan Larimore, and Siva Rajamanickam
% Developed in collaboration with J. Gilbert and E. Ng.

error ('csymamdtestmex mexFunction not found') ;
