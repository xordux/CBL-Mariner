MATLAB interface for CSparse.  See Contents.m for details.

Timothy A. Davis, http://www.suitesparse.com
