function x = cs_pvec (b,p)                                                  %#ok
%CS_PVEC x=b(p)
%
% Example:
%   x = cs_pvec (b,p)
% See also: cs_demo

% Copyright 2006-2012, Timothy A. Davis, http://www.suitesparse.com

error ('cs_pvec mexFunction not found') ;

